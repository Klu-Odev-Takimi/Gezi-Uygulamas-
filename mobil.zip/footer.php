  <!--====================  footer area ====================-->
  <footer>
            <div class="footer-nav-wrapper footer-nav-wrapper--styleTwo">
                <a href="index.php" class="footer-nav-single footer-nav-single--styleTwo">
                    <div class="menu-wrapper">
                        <img src="assets/img/icons/home.svg" class="injectable" alt="">
                    </div>
                </a>
                <a href="favori.php" class="footer-nav-single footer-nav-single--styleTwo active">
                    <div class="menu-wrapper">
                        <img src="assets/img/icons/wish.svg" class="injectable" alt="">
                    </div>
                </a>
                <a href="profil.php" class="footer-nav-single footer-nav-single--styleTwo">
                    <div class="menu-wrapper">
                        <img src="assets/img/icons/profile.svg" class="injectable" alt="">
                    </div>
                </a>
            </div>
        </footer>
        <!--====================  End of footer area  ====================-->
    </div>
    <!-- JS
    ============================================ -->
    <!-- Modernizer JS -->
    <script src="assets/js/modernizr-2.8.3.min.js"></script>
    <!-- jQuery JS -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- SVG inject JS -->
    <script src="assets/js/plugins/svg-inject.min.js"></script>
    <!-- Slick slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Plugins JS (Please remove the comment from below plugins.min.js for better website load performance and remove plugin js files from above) -->
    <!--
  <script src="assets/js/plugins/plugins.min.js"></script>
-->
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>
</html>